#include <iostream>

int main() {
    // Loop from 1 to 10
    for (int i = 1; i <= 10; ++i) {
        std::cout << i << std::endl;
    }
    return 0;
}
