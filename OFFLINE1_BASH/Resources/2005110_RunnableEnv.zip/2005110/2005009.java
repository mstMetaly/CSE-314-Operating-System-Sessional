
public class 2005009 {
    public static void main(String[] args)
    {

    }
}
