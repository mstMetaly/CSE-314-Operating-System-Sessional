#include <stdio.h>

int main() {
    // Print numbers from 1 to 10
    for (int i = 1; i <= 5; i++) {
        printf("%d\n", i);
    }
    return 0;
}
