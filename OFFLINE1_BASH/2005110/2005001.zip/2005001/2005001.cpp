#include <iostream>

int main() {
    // Loop from 1 to 7
    for (int i = 1; i <= 7; i++) {
        std::cout << i << std::endl; // Print each number followed by a newline
    }
    return 0; // Return 0 to indicate successful completion
}
