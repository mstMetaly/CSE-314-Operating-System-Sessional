#include <stdio.h>

int main() {
    // Loop from 1 to 7
    for (int i = 1; i <= 4; i++) {
        printf("%d\n", i); // Print each number followed by a newline
    }
    return 0; // Return 0 to indicate successful completion
}
